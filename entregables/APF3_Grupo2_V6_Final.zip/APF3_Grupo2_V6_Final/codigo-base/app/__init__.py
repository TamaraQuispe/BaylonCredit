"""Credify API application."""
