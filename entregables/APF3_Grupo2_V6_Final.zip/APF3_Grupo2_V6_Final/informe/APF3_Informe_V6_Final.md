# V6 Final | Evidencia para priorizar, no aprobar

Cerveceria Baylon / Credify / APF3 Grupo 2. Informe de investigacion academica.

Continuidad APF1: problema del registro y evaluacion del fiado a un dia. APF2: MVP de clientes, evaluacion, fiados y pagos. APF3: clasificacion supervisada para orientar revision humana, no decision crediticia automatica.

**Edicion V6 Final, revision v6-final-r1.** Se conserva V6 historico. Esta revision prospectiva fue declarada despues de consultar resultados anteriores; no se presenta como un diseno ciego a esa experiencia. Nuevas semillas y nuevos clientes ficticios, mismo simulador y supuestos.

SVM elegida por F2 OOF de politica 0.55236729, frente al arbol 0.54607509. FINAL SVM: F2 0.60606061, precision 0.32000000, recall 0.78048780 (32/41). El arbol logra F2 FINAL 0.64315353; no se reselecciona con el test.

Datos simulados / V6 Final r1 / Revision humana pendiente. Sin firmas ni roles confirmados. Produccion intacta. Esta exportacion solo lee evidencia experimental persistida y prueba reglas puras; no entrena, predice ni simula datos.

<!-- PAGE -->

# 1. Problema, objetivo y alcance

Cada fila representa un fiado otorgado, no una persona independiente. La variable late_payment vale 1 si hay atraso desde el vencimiento contractual y 0 si la liquidacion completa ocurre hasta el vencimiento inclusive. La gracia no cambia atraso a puntualidad; atraso no equivale a perdida definitiva. Etiquetas inmaduras quedan desconocidas, nunca se imputan a cero.

Objetivo: clasificar atraso entre solicitudes elegibles para priorizar revision del propietario. F2 pondera recall (beta=2, decision academica), no un costo monetario aprobado. Se reportan precision, recall, F1, F2 y accuracy; accuracy sola oculta el desbalance. Ningun score concede fiado ni confirma solvencia.

El MVP conserva el flujo cliente > evaluacion > fiado > pagos. Las once entradas son snapshots anteriores a evaluar; IDs, fechas, escenario, saldo al corte y pagos futuros son metadatos excluidos. completed_sales aqui solo incluye ventas ligadas a credito, no toda venta al contado del negocio.

Se evalua transferencia a clientes sinteticos disjuntos del mismo simulador, no validacion real ni temporal prospectiva. No se consulta la base real actual ni se publican archivos privados del propietario.

<!-- PAGE -->

# 2. Poblaciones y denominadores

| Fase estudio | Intentos | Bloqueos | Manual | Elegibles | Conocidos | Clases 0/1 | ? |
| --- | --- | --- | --- | --- | --- | --- | --- |
| DEV | 586 | 45 | 0 | 541 | 534 | 448/86 | 7 |
| FINAL | 292 | 15 | 0 | 277 | 275 | 234/41 | 2 |

Bloqueos y derivaciones humanas no son clase 0 ni clase 1, aciertos ni errores del modelo. Las metricas se condicionan a elegibilidad y desenlace conocido. Los siete desconocidos DEV y dos FINAL pueden competir por la cola pero no ajustan, calibran ni puntuan metricas supervisadas.

Cero derivaciones manuales en estudio no significa que la regla se retiro. Los primeros fiados sin historial pertenecen al warmup: decisiones simuladas autorizadas por propietario, fuera de aprendizaje y evaluacion. Sus liquidaciones observadas pueden aportar historial posterior legitimo.

| Historia | Clientes ejemplo | Warmup fiados | Fiados estudio | Hard pass | Aceptacion global |
| --- | --- | --- | --- | --- | --- |
| DEV D1 | 12 | 46 | 268 | True | False |
| DEV D2 | 12 | 44 | 273 | True | False |
| FINAL | 12 | 45 | 277 | True | False |

Las historias son mundos alternativos de un negocio, no sucursales simultaneas ni volumen real sumable. Doce clientes constituyen un roster de ejemplo, no una poblacion real fija; pueden cambiar semana a semana.

<!-- PAGE -->

# 3. Dos reglas antes del modelo

Primero: cualquier saldo positivo bloquea, incluso vigente, parcial o con acuerdo. Solo la liquidacion completa observada estrictamente antes de evaluar restablece elegibilidad, nunca aprobacion automatica.

Segundo: deuda cero no confirmada o ausencia de fiados totalmente pagados confirmados deriva a revision del propietario. La deuda positiva tiene prioridad sobre falta de historial. Ambos estados evitan consultar el modelo y no producen score.

| Prueba independiente | Resultado verificado | Modelo llamado |
| --- | --- | --- |
| Deuda vigente | blocked_pending_balance | false |
| Saldo parcial | blocked_pending_balance | false |
| Deuda y sin historial: deuda primero | blocked_pending_balance | false |
| Sin fiados liquidados | requires_owner_review | false |
| Historial no confirmado | requires_owner_review | false |
| Deuda no confirmada | requires_owner_review | false |
| Deuda cero e historial confirmado | model_eligible | false |

Estas siete pruebas ejecutan solo la funcion pura pre_model_decision cuyo hash coincide con el protocolo. No cargan artefactos ni ejecutan inferencia. El caso elegible solo verifica que el gate permita continuar; tampoco llama al modelo. No son prueba de despliegue, CLI o reproduccion experimental. Evidencia: pruebas-reglas-previas.json.

<!-- PAGE -->

# 4. Fuente y coherencia acotada

Rildo reviso 23 elementos intencionales V5: 12 fiados, cuatro rechazos, cuatro semanas y tres supuestos. No reviso todas las nuevas filas ni aprobo rendimiento predictivo. Los agregados declarados proceden de recuerdo y revision parcial de cuaderno: 48 anotaciones, 45 evaluables, ocho tardias y tres desconocidas; no son entrenamiento.

La referencia aproximada de 12 fiados a nueve clientes por semana no obliga a un volumen fijo. La precision de montos enteros o .50 y horarios variados procede de la aclaracion; precios exactos tambien se permiten. La mezcla 75/25, distribuciones latentes, rotacion finita, warmup y corte exacto 20:00 siguen siendo supuestos del equipo.

El simulador no cambio: montos S/5..50, cupo supuesto S/80, lognormal truncada y heterogeneidad Beta, abonos supuestos 10/48 y fraccion 0.5, pagos en ventanas 08:00..12:00 y 16:00..20:00. Planes finitos de liquidacion no estiman perdida permanente. No se cambia semilla para mejorar resultados.

**Hard constraints pass=true no equivale a aceptacion global. coherence_accepted=false se conserva en las tres historias.** Las restricciones verifican rangos, integridad temporal y cero otorgamientos con saldo previo; no validez externa. Los controles no convierten datos simulados en datos reales ni sustituyen revision humana.

<!-- PAGE -->

# 5. EDA y contrato de entradas

![Balance y antiguedad frente a ventas completadas: solo 534 filas DEV conocidas.](figuras/eda-dev.png)

Atraso DEV: 86/534 = 16.1049 %. El desbalance exige comparar Dummy y deteccion de clase minoritaria. Antiguedad e historial muestran asociaciones del simulador, no efectos causales ni evidencia de clientes reales.

Cinco entradas constantes por elegibilidad: pending_overdue, pending_current, outstanding, utilization, overdue_rate. completed_sales = paid_credits; no son dos senales independientes. Se preserva contrato sin fabricar variacion.

| Entradas | Sentido y preparacion |
| --- | --- |
| completed_sales, paid_credits, paid_late | Conteos previos; historial de liquidacion y atraso |
| pending_overdue/current, outstanding, utilization, overdue_rate | Pendientes/exposicion: cero en elegibles |
| requested_ratio | Monto solicitado / cupo supuesto 80 |
| tenure_days, punctuality_rate | Dias desde alta; (pagados - tardios) / pagados |

<!-- PAGE -->

# 6. Metodo y seleccion congelada

Pipeline por pliegue: mediana y StandardScaler ajustados solo en entrenamiento conocido. Once variables numericas; sin one-hot ni sobremuestreo. SVM requiere escalado; se conserva procedimiento comparable en arbol y Dummy.

Tres folds externos StratifiedGroupKFold por client_id y tres internos para calibracion sigmoid SVM, ensemble=false. El SVC lineal usa probability=false. Los folds internos permanecen dentro del entrenamiento externo. Clientes disjuntos y ambas clases en cada subconjunto; unknowns no calibran.

![Grilla heredada: 18 configuraciones por siete umbrales; sin ajuste posterior.](figuras/metodo-grilla.png)

Se maximiza F2 OOF de politica con capacidad; desempates: recall, precision, F1, menos revisiones, orden de grilla, cercania a 0.5 y menor umbral. Dummy usa 0.5. No precision minima predeclarada.

OOF se reutiliza para elegir configuracion y umbral: hay optimismo de seleccion. Calibracion interna agrupada no es evaluacion anidada independiente de toda la busqueda. FINAL se genero una vez tras congelar seleccion y hashes; un lote por cada familia sobre 277 elegibles, incluidos dos desconocidos, segun report_checks.json.

<!-- PAGE -->

# 7. Ganador y comparacion OOF

SVM elegida por F2 OOF de politica 0.55236729, frente al arbol 0.54607509. FINAL SVM: F2 0.60606061, precision 0.32000000, recall 0.78048780 (32/41). El arbol logra F2 FINAL 0.64315353; no se reselecciona con el test.

SVM: {"C": 1.0, "class_weight": "balanced", "family": "svm", "kernel": "linear", "probability": false, "random_state": 42}; umbral 0.1. Arbol comparador: {"class_weight": null, "family": "tree", "max_depth": 3, "min_samples_leaf": 16, "random_state": 42}; umbral 0.1.

| Modelo | Particion | Precision | Recall | F1 | F2 | Accuracy |
| --- | --- | --- | --- | --- | --- | --- |
| SVM elegida | oof | 0.21813031 | 0.89534884 | 0.35079727 | 0.55236729 | 0.46629213 |
| Arbol | oof | 0.26446281 | 0.74418605 | 0.39024390 | 0.54607509 | 0.62546816 |
| Dummy mayoria | oof | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.83895131 |
| Dummy positivo | oof | 0.16104869 | 1.00000000 | 0.27741935 | 0.48974943 | 0.16104869 |

La diferencia OOF entre familias es pequena y no establece superioridad estadistica. La cola OOF se forma por fold, replica y fecha, no como competencia conjunta bajo un unico modelo desplegado.

Semillas nuevas DEV: 2026112601, 2026112602; FINAL: 2026112603; CV externa/interna: 2026112604/2026112605. Los prefijos PND6F-R1-D1/D2/T identifican clientes nuevos. Esta revision dentro de V6 no borra ni reemplaza evidencia historica.

<!-- PAGE -->

# 8. FINAL: RAW y politica

RAW aplica umbral sin limite diario; POLICY aplica la cola limitada. Positiva=atraso, n=275 conocidos. Precision indefinida se informa como cero. No se incluyen los dos desconocidos como puntuales.

## RAW FINAL

| Modelo | Particion | Precision | Recall | F1 | F2 | Accuracy |
| --- | --- | --- | --- | --- | --- | --- |
| SVM elegida | final | 0.32000000 | 0.78048780 | 0.45390071 | 0.60606061 | 0.72000000 |
| Arbol | final | 0.40259740 | 0.75609756 | 0.52542373 | 0.64315353 | 0.79636364 |
| Dummy mayoria | final | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.85090909 |
| Dummy positivo | final | 0.14909091 | 1.00000000 | 0.25949367 | 0.46697039 | 0.14909091 |

## POLICY FINAL

| Modelo | Particion | Precision | Recall | F1 | F2 | Accuracy |
| --- | --- | --- | --- | --- | --- | --- |
| SVM elegida | final | 0.32000000 | 0.78048780 | 0.45390071 | 0.60606061 | 0.72000000 |
| Arbol | final | 0.40259740 | 0.75609756 | 0.52542373 | 0.64315353 | 0.79636364 |
| Dummy mayoria | final | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.85090909 |
| Dummy positivo | final | 0.15073529 | 1.00000000 | 0.26198083 | 0.47018349 | 0.16000000 |

SVM elegida por F2 OOF de politica 0.55236729, frente al arbol 0.54607509. FINAL SVM: F2 0.60606061, precision 0.32000000, recall 0.78048780 (32/41). El arbol logra F2 FINAL 0.64315353; no se reselecciona con el test.

Dummy mayoritario puede tener accuracy alta sin detectar atrasos. Dummy positivo RAW y limitado no son la misma decision ni el mismo numero de revisiones. Se conservan ambos baselines, incluso cuando la precision de SVM es baja. No hay intervalos de confianza independientes por transaccion: son fiados repetidos por cliente sintetico.

<!-- PAGE -->

# 9. Errores e interpretacion prudente

![Matriz SVM FINAL: filas reales, columnas predichas, orden 0/1.](figuras/confusion-final.png)

166 TN, 68 FP, nueve FN y 32 TP. Detectar 32 de 41 atrasos no oculta nueve omisiones. Las falsas alertas generan trabajo; un score bajo no garantiza puntualidad.

| Caso (primeros por ID) | Tipo RAW/POLICY | Real/predicho | Score |
| --- | --- | --- | --- |
| PND6F-R1-T-L00051 | FN/FN | 1/0 | 0.08781869 |
| PND6F-R1-T-L00054 | FP/FP | 0/1 | 0.22631908 |
| PND6F-R1-T-L00058 | FN/FN | 1/0 | 0.08798598 |

Un historial puntual puede preceder un atraso y uno tardio puede preceder un pago puntual; son hipotesis interpretativas, no causas probadas. Se usan tres errores deterministas del cache, no otra prediccion. Coeficientes estandarizados SVM describen el margen, no probabilidades ni impactos causales; calibracion convierte margen a score y no demuestra calibracion en poblacion real. El anexo conserva todos los coeficientes.

<!-- PAGE -->

# 10. Cola y utilidad no demostrada

Umbral > ordenar score descendente > desempate por ID ficticio > hasta cinco alertas por replica y dia civil Lima. Dos minutos por caso y cinco/dia son hipotesis no medidas, no capacidad aprobada.

| Politica | Total | Conocidas | Sin label | Max/dia | Dias sobre antes | Min hip. |
| --- | --- | --- | --- | --- | --- | --- |
| SVM elegida | 100 | 100 | 0 | 3 | 0 | 200 |
| Arbol | 77 | 77 | 0 | 3 | 0 | 154 |
| Dummy mayoria | 0 | 0 | 0 | 0 | 0 | 0 |
| Dummy positivo | 274 | 272 | 2 | 5 | 3 | 548 |

SVM: 100 revisiones frente a 274 de Dummy positivo limitado. 174 menos x 2 minutos = 348 minutos HIPOTETICOS, no ahorro observado. Los FN pasan de 0 en Dummy limitado a 9 en SVM; 68 FP tambien consumen tiempo. No hay ganancias garantizadas.

La cola cuenta alertas sobre fiados otorgados elegibles, no todo el trabajo del negocio. Bloqueos, revision obligatoria del primer fiado, cobranza y otras tareas no se consideran gratuitas ni aciertos. Dos desconocidos FINAL quedan fuera de alertas SVM; la tabla conserva su participacion en otras politicas.

Antes de recomendar uso: medir tiempos ANTES/DESPUES en periodos comparables, obtener desenlaces maduros, registrar FN/FP y consecuencias, acordar costos y tolerancias con el propietario. No se demuestra reduccion de perdidas, aumento de ventas ni ahorro operativo real.

<!-- PAGE -->

# 11. Ejemplo e integracion: evidencia guardada

Ejemplo ficticio distinto de los vectores de estudio, etiqueta desconocida. Solicitud S/20 sobre cupo S/80, deuda cero, seis fiados pagados y uno tardio. Solo se muestra la salida ya persistida.

| Campo guardado | Valor |
| --- | --- |
| family | svm |
| probability | 0.15310676521820216 |
| threshold | 0.1 |
| predicted | 1 |
| known_label | None |
| business_approval | False |
| review_policy_applied | False |

Score superior al umbral: candidato a revision, no aprobacion ni acierto demostrado. Una solicitud aislada no ejecuta la cola diaria; known_label=null impide afirmar correccion. No se repite inferencia para confeccionar este informe.

**Estado tecnico consultable en manifiesto.** Esta edicion no acredita nuevo despliegue, reproduccion independiente, latencia ni ensayo humano de V6 Final. La demo historica no prueba instalacion de estos artefactos. Produccion intacta: no se modifican servicios, runners ni paquetes.

Integracion propuesta para PROY: snapshot validado > dos gates > artefacto confiable versionado > score > cola compartida > decision humana y auditoria. Requiere pruebas transaccionales, autenticacion, rollback y piloto real autorizado antes de operar; Joblib solo desde origen confiable.

<!-- PAGE -->

# 12. Riesgos, gobernanza y cierre

Ley N. 29733 y D.S. N. 016-2024-JUS: marco documental de privacidad, no certificacion juridica actualizada. Antes de clientes reales: finalidad y base juridica, informacion/consentimiento aplicable, minimizacion, accesos, conservacion, seguridad y derechos ARCO. Solo se leen fuentes agregadas sanitizadas, no documentos privados, identidades de clientes ni firmas.

| Riesgo | Control propuesto; responsable por confirmar |
| --- | --- |
| Generalizacion sintetica limitada | Piloto real consentido y test prospectivo nuevo; no retocar este FINAL |
| Nueve FN y 68 FP | Acordar tolerancias y medir consecuencias/minutos |
| Integracion y version incorrecta | QA de contrato, hashes, gates y rollback |
| Privacidad y aceptacion incompleta | Revision legal y grupal antes de operar |

Conclusiones: V6 Final selecciona SVM en DEV y conserva la ventaja del arbol en FINAL sin reseleccion. La evidencia permite estudiar priorizacion, no aprobar creditos. Hard pass y menor cola no implican coherencia global aceptada, utilidad real ni autorizacion comercial. El simulador y sus limitaciones permanecen.

Cuatro revisiones individuales pendientes: Omara Baylon, Tamara Covenas, Cesar Paredes y Pablo Yman. Asignacion de exposicion y ensayo pendientes; no se inventan firmas, aportes confirmados ni autorizaciones. Asistencia IA: redaccion y exportacion automatizada; verificacion humana de contenido y entrega aun pendiente.

<!-- PAGE -->

# Referencias y trazabilidad

Grupo 2 (2026). APF1/APF2, continuidad del problema y MVP, segun documentacion heredada. No se adjuntan fuentes privadas ni se atribuye nueva auditoria a esos documentos.

Protocolo v6-final-r1: revision_protocol.json. Protocolo heredado de datos/modelado: APF3_PENDING_V6_DATA_PROTOCOL.json y APF3_PENDING_V6_MODEL_PROTOCOL.json. Fuentes agregadas: APF3_OWNER_ANCHORS_V4.json y APF3_OWNER_REVIEW_V5.json.

Resultados primarios: pending_v6_report.json, frozen_selection.json, final_cache_*.json, illustrative_output.json y report_checks.json, todos bajo experiment/. Plan de folds y congelacion: planned_folds.json y freeze_before_final.json.

Pedregosa et al. (2011). Scikit-learn: Machine Learning in Python. JMLR 12, 2825-2830. Congreso del Peru (2011). Ley N. 29733. MINJUSDH (2024). D.S. N. 016-2024-JUS.

El manifiesto documental registra hashes de entradas y salidas, verificaciones de texto PDF y geometria. No equivale a certificacion experimental o revision humana. Estado tecnico consultable en manifiesto.

<!-- PAGE -->

# Anexo A. Ajuste aparente frente a OOF

| Modelo | Particion | Precision | Recall | F1 | F2 | Accuracy |
| --- | --- | --- | --- | --- | --- | --- |
| SVM elegida | train | 0.25783972 | 0.86046512 | 0.39678284 | 0.58637084 | 0.57865169 |
| SVM elegida | oof | 0.21813031 | 0.89534884 | 0.35079727 | 0.55236729 | 0.46629213 |
| Arbol | train | 0.28870293 | 0.80232558 | 0.42461538 | 0.59176672 | 0.64981273 |
| Arbol | oof | 0.26446281 | 0.74418605 | 0.39024390 | 0.54607509 | 0.62546816 |
| Dummy mayoria | train | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.83895131 |
| Dummy mayoria | oof | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.83895131 |
| Dummy positivo | train | 0.16104869 | 1.00000000 | 0.27741935 | 0.48974943 | 0.16104869 |
| Dummy positivo | oof | 0.16104869 | 1.00000000 | 0.27741935 | 0.48974943 | 0.16104869 |

Train es ajuste aparente, no evaluacion independiente. Las diferencias train/OOF permiten examinar sobreajuste sin concluir causalidad ni cambiar umbral. OOF usado en seleccion tiene optimismo. Arbol limita profundidad y hoja; SVM regulariza con C y calibra dentro de grupos. Los valores son exactamente los persistidos; no se ajusta ningun estimador al exportar.

<!-- PAGE -->

# Anexo B. Entradas, margen y ejemplo

| Variable | Coeficiente SVM estandarizado | Entrada ilustrativa |
| --- | --- | --- |
| completed_sales | -0.04382680 | 6 |
| paid_credits | -0.04382680 | 6 |
| paid_late | 0.39655327 | 1 |
| pending_overdue | 0.00000000 | 0 |
| pending_current | 0.00000000 | 0 |
| outstanding | 0.00000000 | 0 |
| utilization | 0.00000000 | 0 |
| requested_ratio | -0.06426819 | 0.25 |
| tenure_days | -0.10765347 | 60 |
| punctuality_rate | -0.61391240 | 0.8333333333333334 |
| overdue_rate | 0.00000000 | 0 |

Puntualidad negativa y paid_late positivo describen asociaciones del margen dentro del simulador; no efectos de cambiar el comportamiento. Coeficientes de variables duplicadas reparten contribucion; constantes no tienen capacidad explicativa. El score ilustrativo proviene del artefacto seleccionado ya ejecutado y guardado.

Los errores completos, once entradas de cada caso y metricas integrales permanecen en experiment/. No se copian archivos privados ni se alteran artefactos para presentar resultados.
