# V6 Final

Revision prospectiva `v6-final-r1`, autorizada por el usuario para reentrenar y
obtener nuevos resultados finales. Datos 100 % simulados; no uso comercial.

La ejecucion V6 anterior permanece sin cambios. Esta revision aplica ambas reglas
del propietario antes del modelo: bloqueo por saldo pendiente y revision humana
sin fiados pagados. Bloqueos y revisiones no se cuentan como aciertos del modelo.

El protocolo y los hashes se fijan antes de generar nuevos datos DEV. La prueba
FINAL nueva solo se genera tras congelar seleccion y modelos. No hay ajuste de
semillas, datos o modelo en funcion de los resultados finales.

La ejecucion autorizada esta concluida y congelada en `experiment/`. La seleccion
OOF eligio SVM con umbral `0.1`. FINAL tiene 277 elegibles, 275 etiquetas conocidas
y 2 desconocidas. La matriz RAW SVM es `[[166, 68], [9, 32]]`, precision `0.32`,
recall `0.7804878048780488`, F1 `0.45390070921985815`, F2 `0.6060606060606061`
y accuracy `0.72`. No se selecciono ni ajusto el modelo usando FINAL.

## Estado De Entrega

La publicacion tecnica exige integridad de fuentes/artefactos, congelacion y
llamadas correctas, reglas previas, reconstruccion completa RAW y de colas desde
scores OOF/FINAL, seleccion OOF, las mismas filas elegibles para las cuatro familias,
y documentos/despliegue coherentes. `verificacion-v6-final.json` separa
`release_required_checks` de `optional_coverage` y `coverage_limitations`.

El manifiesto congelado no contiene scores TRAIN por fila: `training_reports.json`
guarda agregados. Se comprobaron sus vinculos, matrices, precision, recall, F1, F2,
accuracy derivadas de confusion y consistencia agregada de colas. La reconstruccion
TRAIN por score y de su cola queda `not_available`: es una limitacion de cobertura,
no un bloqueo de publicacion de los resultados OOF/FINAL reconstruidos.
ROC AUC y Brier, incluidos los de TRAIN, son valores de fuente verificada por hash,
no recalculados. No se infiere, modifica evidencia ni inventa un cache TRAIN.

La verificacion bloqueada anterior se conserva como historia bajo `support/history/`;
no representa el criterio de publicacion actual. El ZIP final solo se publica tras
pasar los checks obligatorios; esto no equivale a aprobacion humana o comercial.

Esta finalizacion no entrena, no infiere y no genera cohortes. Reconstruir metricas
desde caches es verificacion, no una segunda validacion independiente ni una
reproduccion nueva del entrenamiento. No se modifican `experiment/`,
`development/`, `informe/` ni `sustentacion/`. Los V6 anteriores se conservan.

## Contenido

- `informe/`: informe generado de 16 paginas totales, 12 de cuerpo; manifiestos existentes.
- `sustentacion/`: 13 diapositivas y guion de 3 paginas; sin regeneracion.
- `codigo-base/`: copia exacta de los 21 archivos del codepack inmutable anterior.
- `revision/`: runner final y politica congelados, sin cambios.
- `sources/`: protocolo final, cuatro fuentes heredadas y resultados documentados.
- `tools/`: verificador stdlib, pruebas, generadores y harness de reproduccion futura.
- `ejemplos/`: tres entradas manuales ilustrativas y expectativas, no nuevas inferencias.
- `support/`: manifiesto de soporte y copia sanitizada del registro de despliegue.
- `REPRODUCCION.md`, `Dockerfile`, `requirements.txt`: receta portable; no ejecutada ahora.

## Despliegue Y Limites

El registro publico existente declara despliegue y verificacion satisfactorios de
la demo academica sintetica. No se despliega ni se modifica nada durante esta
finalizacion. Solo la probabilidad ilustrativa admite `abs_tol=1e-12, rel_tol=0`:
valor congelado `0.15310676521820216`, API `0.15310676521820044`, diferencia
`1.7208456881689926e-15`. No es igualdad numerica exacta. Modelos, clase, umbral,
metricas y hashes siguen siendo exactos; esa tolerancia no se extiende a ellos.

Revision humana de los cuatro integrantes, ensayo y entrega academica: PENDIENTE.
No hay aprobacion comercial, firma fabricada ni validacion predictiva con clientes reales.
