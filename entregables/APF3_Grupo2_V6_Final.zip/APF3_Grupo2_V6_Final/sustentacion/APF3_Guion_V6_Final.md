# Guion conciso V6 Final

Datos simulados / V6 Final r1 / Revision humana pendiente

Guion de apoyo, no ensayo certificado. Distribucion de expositores por confirmar. No se ejecuta entrenamiento, inferencia ni simulacion. Propuesta: 10-12 minutos, duracion real pendiente.

## 1. Fiado a un dia: evidencia, no aprobacion

El problema de APF1 continua en el MVP de APF2. APF3 estudia priorizacion humana con datos simulados. Esta es V6 Final r1, no otra version numerada. Se preserva V6 historico; no se toca produccion.

## 2. Elegibilidad antes de cualquier score

Cualquier saldo bloquea, vigente o parcial. Sin historial pagado confirmado, revision del propietario. La deuda tiene prioridad. Siete pruebas de la funcion pura pasan sin llamar al modelo. Bloqueos no son aciertos.

## 3. Poblaciones: no mezclar denominadores

DEV estudio registra 586 intentos y FINAL 292. Cero manuales no elimina el gate: los primeros fiados estan en warmup. Desconocidos compiten en cola, no se imputan ni entran a metricas.

## 4. EDA DEV: senal sintetica, no causalidad

Hay 448 puntuales y 86 atrasos conocidos. Son fiados repetidos por cliente, no personas independientes. Cinco entradas son cero y ventas completadas duplica fiados pagados. No fabricamos variacion.

<!-- PAGE -->

# Guion: metodo y resultados

## 5. Metodo: grupos, calibracion y grilla fija

Tres folds externos por cliente y tres internos de calibracion sigmoid. Mediana y escalado se ajustan solo dentro de entrenamiento. Hay 126 pares. OOF selecciona: conserva optimismo, no es evaluacion anidada completa.

## 6. Seleccion OOF: SVM, umbral 0.1

SVM elegida por F2 OOF de politica 0.55236729, frente al arbol 0.54607509. FINAL SVM: F2 0.60606061, precision 0.32000000, recall 0.78048780 (32/41). El arbol logra F2 FINAL 0.64315353; no se reselecciona con el test. SVM C uno, balanced, lineal, probability false; sigmoid interno. El arbol comparador tiene profundidad tres, hoja dieciseis y sin ponderacion. No cambiamos con FINAL.

## 7. Comparacion RAW FINAL

Se muestran las cinco metricas para SVM, arbol y ambos Dummy. Accuracy sola no sirve para detectar atrasos. El arbol logra mejor F2 FINAL; observarlo no autoriza reseleccion.

## 8. Comparacion POLICY FINAL

La politica limita cinco por replica y fecha. Son decisiones distintas de RAW en general. Los desconocidos compiten sin etiqueta. Se conservan los dos baselines y la carga completa en el informe.

## 9. Matriz SVM: errores visibles

SVM detecta 32 de 41 atrasos, pero omite nueve. Produce 68 falsas alertas. Precision 0.32; un pasado puntual no garantiza el siguiente pago. Los primeros errores por ID se conservan en el informe.

<!-- PAGE -->

# Guion: utilidad, limites y cierre

## 10. Menor cola no significa ahorro

SVM: 100 revisiones frente a 274 de Dummy positivo limitado. 174 menos x 2 minutos = 348 minutos HIPOTETICOS, no ahorro observado. Los FN pasan de 0 en Dummy limitado a 9 en SVM; 68 FP tambien consumen tiempo. No hay ganancias garantizadas. Los dos minutos por caso son una hipotesis. Necesitamos tiempos reales comparables y costos de omitir atrasos.

## 11. Ejemplo: salida guardada del artefacto

Ejemplo S/20, seis pagados, uno tarde. Score persistido 0.15310676521820216, umbral 0.1. Etiqueta desconocida: no demuestra acierto. No corremos inferencia en la exposicion documental. La cola requiere lote; no se aplica a este ejemplo aislado.

## 12. Alcance tecnico y revision de fuente

Rildo reviso 23 elementos V5, no todas las filas nuevas. Doce clientes son un ejemplo. Hard pass no significa coherence accepted: sigue falso. Estado tecnico consultable en manifiesto; esta exportacion no certifica despliegue ni reproduccion de V6 Final.

## 13. Cierre: antes de operar, medir y revisar

No hay autorizacion comercial ni firmas inventadas. Las cuatro revisiones individuales y ensayo siguen pendientes. Para PROY hacen falta piloto real autorizado, privacidad conforme a Ley 29733, QA de integracion y costos acordados. La seleccion se conserva, incluidos sus nueve FN; evidencia academica no es validacion empresarial.

Revision pendiente: Omara Baylon, Tamara Covenas, Cesar Paredes y Pablo Yman. No hay firmas ni roles confirmados. Si preguntan por despliegue/reproduccion: estado tecnico consultable en manifiesto, sin afirmar exito no verificado.
